export const environment = {
  production: true
  ,name: 'Production'
  ,firebaseConfig: {
    apiKey: "AIzaSyAJqEztFRYYgp-S-WAJO20M_YNOnA_xfv8",
    authDomain: "sopps.firebaseapp.com",
    databaseURL: "https://sopps.firebaseio.com",
    projectId: "firebase-sopps",
    storageBucket: "firebase-sopps.appspot.com",
    messagingSenderId: "630469965694"
		/*apiKey: "YOUR_API_KEY",
		 authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
		 databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
		 storageBucket: "YOUR_PROJECT_ID.appspot.com",
		 messagingSenderId: "YOUR_MESSAGE_ID"*/
  }
};
