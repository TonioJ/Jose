import { Component } from '@angular/core';

@Component({
  moduleId:    module.id,
  selector: 'starter-project-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent  {
  name = 'StarterProject';
}
